let timer;
let isRunning = false;
let lapCount = 1;

function startStop() {
    const startStopButton = document.getElementById("startStop");
    if (isRunning) {
        clearInterval(timer);
        startStopButton.textContent = "Start";
    } else {
        timer = setInterval(updateTime, 1000);
        startStopButton.textContent = "Stop";
    }
    isRunning = !isRunning;
}

function updateTime() {
    const display = document.getElementById("display");
    const time = display.textContent.split(":");
    let seconds = parseInt(time[2], 10);
    let minutes = parseInt(time[1], 10);
    let hours = parseInt(time[0], 10);

    seconds++;

    if (seconds === 60) {
        seconds = 0;
        minutes++;

        if (minutes === 60) {
            minutes = 0;
            hours++;
        }
    }

    display.textContent =
        (hours < 10 ? "0" : "") + hours +
        ":" +
        (minutes < 10 ? "0" : "") + minutes +
        ":" +
        (seconds < 10 ? "0" : "") + seconds;
}

function lap() {
    if (isRunning) {
        const lapsContainer = document.getElementById("laps");
        const lapItem = document.createElement("li");
        lapItem.textContent = "Lap " + lapCount + ": " + document.getElementById("display").textContent;
        lapsContainer.appendChild(lapItem);
        lapCount++;
    }
}

function reset() {
    clearInterval(timer);
    isRunning = false;
    lapCount = 1;
    document.getElementById("startStop").textContent = "Start";
    document.getElementById("display").textContent = "00:00:00";
    document.getElementById("laps").innerHTML = "";
}